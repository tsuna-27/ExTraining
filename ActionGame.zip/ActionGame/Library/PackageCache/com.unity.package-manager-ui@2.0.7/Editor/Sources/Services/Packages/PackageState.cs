﻿namespace UnityEditor.PackageManager.UI
{
    internal enum PackageState {
        UpToDate,
        Outdated,
        InProgress,
        Error
    }
}